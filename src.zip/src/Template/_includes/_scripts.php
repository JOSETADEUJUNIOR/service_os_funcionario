<!-- <![endif]-->

<!--[if IE]>
<script src="assets/js/jquery-1.11.3.min.js"></script>
<![endif]-->

<script src="../Template/assets/js/jquery-2.1.4.min.js"></script>
<script src="../Template/assets/js/bootstrap.min.js"></script>

<!-- page specific plugin scripts -->

<!--[if lte IE 8]>
		  <script src="assets/js/excanvas.min.js"></script>
		<![endif]-->
<script src="../Template/assets/js/jquery-ui.custom.min.js"></script>
<script src="../Template/assets/js/jquery.ui.touch-punch.min.js"></script>
<script src="../Template/assets/js/jquery.easypiechart.min.js"></script>
<script src="../Template/assets/js/jquery.sparkline.index.min.js"></script>
<script src="../Template/assets/js/jquery.flot.min.js"></script>
<script src="../Template/assets/js/jquery.flot.pie.min.js"></script>
<script src="../Template/assets/js/jquery.flot.resize.min.js"></script>
<script src="../Template/plugins/toastr/toastr.min.js"></script>
<script src="../Resource/js/mensagem.js"></script>
<script src="../Resource/js/validar.js"></script>
<script src="../Resource/js/funcoes.js"></script>
<script src="../Template/assets/js/jquery.mask.min.js"></script>
<script src="../Template/assets/js/mask.js"></script>
<!-- ace scripts -->
<script src="../Template/assets/js/ace-elements.min.js"></script>
<script src="../Template/assets/js/ace.min.js"></script>